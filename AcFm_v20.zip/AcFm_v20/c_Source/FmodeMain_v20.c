# include<math.h>
# include<stdio.h>
# include<stdlib.h>
#include<string.h>
# define pi 3.14159265358979
# define G 6.673e-11
# define c 2.99792458e8
# define M 1.989e30
# define Cri 1e-7
# define Gc2 7.42471382405e-28
# define Gc4 8.26110825251e-45

static double a[1500],b[1500],n,l=2;
static int j=0,scr=0;
char filename[30],dysm[6]="/-\\/-\\";
FILE *inf,*outf;
double temp_rhoc,temp_M,temp_R,temp_freq,temp_dpt;

double che(e)
double e;
{
double le;
double p,lp;
int i=0;
le=log10(e);
i=j-1;
for(;i>0;i--)
{
if(le>a[i-1])
  {
  lp=b[i-1]*(le-a[i])/(a[i-1]-a[i])+b[i]*(le-a[i-1])/(a[i]-a[i-1]);
  p=pow(10,lp);
  return(p);
  }
}
return(0);
}

double ch(p)
double p;
{
double lp;
double e,le;
int i=0;
lp=log10(p);
i=j-1;
for(;i>0;i--)
{
if(lp>b[i-1])
  {
  le=a[i-1]*(lp-b[i])/(b[i-1]-b[i])+a[i]*(lp-b[i-1])/(b[i]-b[i-1]);
  e=pow(10,le);
  return(e);
  }
}
return(0);
}

double fp(r,p,e,m)
double r,p,e,m;
{
return(-G*(e+p/c/c)*(m+4*pi*r*r*r*p/c/c)/(r*r-2*r*m*Gc2));
}

double fm(r,e)
double r,e;
{
return(4*pi*r*r*e);
}

double Bf(r,p,m,B)
double r,p,m,B;
{
return(2*Gc2/r/r*(m+4*pi*r*r*r*p/c/c)*B/(1-2*Gc2*m/r));
}

double DH1(r,m,A,p,e,H1,H0,K,V)
double r,m,A,p,e,H1,H0,K,V;
{
double dH1;
return(-1/r*(l+1+2*m*A/r+4*pi*r*r*A*(p-e))*H1+1/r*A*(H0+K-16*pi*(e+p)*V));
}

double DK(r,H0,H1,Dv,K,e,p,A,W)
double r,H0,H1,Dv,K,e,p,A,W;
{
return(1/r*H0+0.5*l*(l+1)/r*H1-((l+1)/r-0.5*Dv)*K-8*pi*(e+p)*sqrt(A)/r*W);
}

double DW(r,W,A,gamma,p,B,X,V,H0,K)
double r,W,A,gamma,p,B,X,V,H0,K;
{
return(-(l+1)/r*W+r*sqrt(A)*(1/gamma/p/sqrt(B)*X-l*(l+1)/r/r*V+0.5*H0+K));
}

double DX(r,X,e,p,B,Dv,H0,w,H1,K,V,A,F,W)
double r,X,e,p,B,Dv,H0,w,H1,K,V,A,F,W;
{
return(-l/r*X+(e+p)*sqrt(B)*(0.5*(1/r-0.5*Dv)*H0+0.5*(r*w*w/B+0.5*l*(l+1)/r)*H1+0.5*(1.5*Dv-1/r)*K-0.5*l*(l+1)*Dv/r/r*V-1/r*(4*pi*(e+p)*sqrt(A)+w*w*sqrt(A)/B-0.5*r*r*F)*W));
}

double H0f(r,B,X,m,p,A,H1,K,w)
double r,B,X,m,p,A,H1,K,w;
{
double H0=8*pi*r*r*r/sqrt(B)*X-(0.5*l*(l+1)*(m+4*pi*r*r*r*p)-w*w*r*r*r/A/B)*H1+(0.5*(l+2)*(l-1)*r-w*w*r*r*r/B-1/r*A*(m+4*pi*r*r*r*p)*(3*m-r+4*pi*r*r*r*p))*K;
H0=H0/(3*m+0.5*(l+2)*(l-1)*r+4*pi*r*r*r*p);
return(H0);
}

double Vf(r,w,e,p,B,A,Dp,W,H0,X)
double r,w,e,p,B,A,Dp,W,H0,X;
{
return(1/w/w/(e+p)*B*(1/sqrt(B)*X+1/r*Dp/sqrt(A)*W-0.5*(e+p)*H0));
}

double gf(e)
double e;
{
double le, p, gamma;
int i=j-1;
e=e/G*c*c;
le=log10(e);
gamma=(e+p/c/c)/e*(b[1]-b[0])/(a[1]-a[0]);
for(;i>0;i--)
  {
  if(le>a[i-1])
    {
    p=b[i-1]*(le-a[i])/(a[i-1]-a[i])+b[i]*(le-a[i-1])/(a[i]-a[i-1]);
    p=pow(10,p);
    gamma=(e+p/c/c)/e*(b[i]-b[i-1])/(a[i]-a[i-1]);
    return(gamma);
    }
  }
return(gamma);
}

double Ff(r,A,e,p,m,Dp)
double r,A,e,p,m,Dp;
{
double F;
F=8*pi/r/r*sqrt(A);
F=F*(e+3*p+r*Dp-(m/4/pi/r/r/r+p)*(4+A*(m/r-4*pi*r*r*e)));
return(F);
}



int fmode(e0)
double e0;
{
FILE *mfile,*pfile,*rhofile,*Bfile,*Bcor,*Wfile,*Wfile1,*Wfile2,*Vfile,*Vfile1,*Vfile2;
double dr=0.5,copy;
double r,r0=1,R,RR,drx,rx;
double ne,p0,p,e,m,mR,dm,A,B=1.0,dB,BR,Bfactor,m1,m2,m3,m4,p1,p2,p3,p4,B1,B2,B3,B4,power,Ibar,I=0,J,DDf,Df=0,f=1;
double H1,H0,K,W,X,F,V,Dv,gamma,Dp,N;
double DH11,DK1,DW1,DX1,H01,H02,K1,K2,x,X1,X2,Xp1,Xp2,W1,W2,V1,V2,V01,V02,V0;
double w,wcheck,o[2],wi,aR,bR,gR,hR,kR,n,Y1,Y2,Z,DZ,DDZ,VZ,Ar1,Ar2,Ai1,Ai2,ar,ai,Ar[2],Ai[2],Br[2],Bi[2];
int t,q;

scr++;printf("\b%c",dysm[scr%6]);
power=pow(10,b[0]);
  mfile=fopen(".\\fmode_temp\\minside.dat","w");
  rhofile=fopen(".\\fmode_temp\\einside.dat","w");
  pfile=fopen(".\\fmode_temp\\pinside.dat","w");
  Bfile=fopen(".\\fmode_temp\\Binside.dat","w");
  r=r0;
  ne=e0;
  e=e0;
  e0=e0*Gc2;
  p=che(e);
  p0=p*Gc4;
  m=4*r*r*pi*e*r/3;
  for(;p>power; r=r+dr)
    {
    fprintf(rhofile,"%.15e\n",e*Gc2);   /*-- e,p,m in G=c=1 --*/
    fprintf(pfile,"%.15e\n",p*Gc4);
    fprintf(Bfile,"%f\n",B);
    fprintf(mfile,"%.15e\n",m*Gc2);
    A=1/(1-2*m*Gc2/r);
    p1=fp(r,p,e,m);
    m1=fm(r,e);
    if((p+dr*p1/2)>power) e=ch(p+dr*p1/2); else break;
    B1=Bf(r,p,m,B);
    p2=fp(r+dr/2,p+dr*p1/2,e,m+dr*m1/2);
    m2=fm(r+dr/2,e);
    if((p+dr*p2/2)>power) e=ch(p+dr*p2/2); else break;
    B2=Bf(r+dr/2,p+dr*p1/2,m+dr*m1/2,B+dr*B1/2);
    p3=fp(r+dr/2,p+dr*p2/2,e,m+dr*m2/2);
    m3=fm(r+dr/2,e);
    if((p+dr*p3)>power) e=ch(p+dr*p3); else break;
    B3=Bf(r+dr/2,p+dr*p2/2,m+dr*m2/2,B+dr*B2/2);
    p4=fp(r+dr,p+dr*p3,e,m+dr*m3);
    m4=fm(r+dr,e);
    B4=Bf(r+dr,p+dr*p3,m+dr*m3,B+dr*B3);
    J=-4*pi*(e+p/c/c)*Gc2*r*A;
    DDf=-(4/r*Df+J*Df+4/r*J*f);
    I=I-2.0/3*f*J/sqrt(A*B)*r*r*r*dr;
    p=p+dr*(p1+2*p2+2*p3+p4)/6;
    e=ch(p);
    dm=dr*(m1+2*m2+2*m3+m4)/6;
    m=m+dm;
    B=B+dr*(B1+2*B2+2*B3+B4)/6;
    f=f+Df*dr;
    Df=Df+DDf*dr;
    }
  R=r;
  mR=m*Gc2;
  BR=1-2*Gc2*m/r;
  Bfactor=BR/B;
  gamma=(b[1]-b[0])/(a[1]-a[0]);
  N=1/(gamma-1);
  RR=R-(N+1)*(p-dr*(p1+2*p2+2*p3+p4)/6)/(p1+2*p2+2*p3+p4)*6;
  fclose(rhofile);
  fclose(pfile);
  fclose(Bfile);
  fclose(mfile);
  Bfile=fopen(".\\fmode_temp\\Binside.dat","r");
  Bcor=fopen(".\\fmode_temp\\Bcor.dat","w");
    scr++;printf("\b%c",dysm[scr%6]);
  while(fscanf(Bfile,"%lf",&copy)==1){fprintf(Bcor,"%f\n",copy*Bfactor);}
  fclose(Bfile);
  fclose(Bcor);
  I=I/sqrt(Bfactor);
  I=I/(f+2*I/r/r/r)/Gc2;
  I=m*sqrt(m/I)*Gc2;
  o[0]=(-0.0047+0.133*I+0.575*I*I)/mR-0.1e-5;
  o[1]=o[0]+0.2e-5;

q=1;
wcheck=0;
for(t=0;;t++)
{
	scr++;printf("\b%c",dysm[scr%6]);
if(t==0)
w=o[t];
else
w=o[q];

/*-- inner solutions --*/

   /*-- Solution 1--*/
Wfile=fopen(".\\fmode_temp\\W1.dat","w");
Vfile=fopen(".\\fmode_temp\\V1.dat","w");
mfile=fopen(".\\fmode_temp\\minside.dat","r");
rhofile=fopen(".\\fmode_temp\\einside.dat","r");
pfile=fopen(".\\fmode_temp\\pinside.dat","r");
fscanf(pfile,"%lf",&p);
fscanf(rhofile,"%lf",&e);
Bcor=fopen(".\\fmode_temp\\Bcor.dat","r");
fscanf(Bcor,"%lf",&B);
fclose(Bcor);
fclose(rhofile);
fclose(pfile);

W=1.0; K=(e+p);
X=(e+p)*sqrt(B)*((4*pi/3*(e+3*p)-w*w/B/l)*W+0.5*K); 
H1=(2*l*K+16*pi*(e+p)*W)/l/(l+1);

rhofile=fopen(".\\fmode_temp\\einside.dat","r");
pfile=fopen(".\\fmode_temp\\pinside.dat","r");
Bcor=fopen(".\\fmode_temp\\Bcor.dat","r");


r=r0; 
while(r<=R)
{
fscanf(pfile,"%lf",&p);
fscanf(rhofile,"%lf",&e);
fscanf(Bcor,"%lf",&B);
fscanf(mfile,"%lf",&m);
if((wcheck-w)/w>-Cri&&(wcheck-w)/w<Cri)
{
fprintf(Wfile,"%.15e\n",sqrt(1-2*m/r)*W);
}

Dp=-(e+p)*(m+4*pi*r*r*r*p)/r/r/(1-2*m/r);
Dv=-2*Dp/(e+p);


A=1/(1-2*m/r);
gamma=gf(e);
H0=H0f(r,B,X,m,p,A,H1,K,w);
V=Vf(r,w,e,p,B,A,Dp,W,H0,X);
if(r==r0)V01=V;else;
if((wcheck-w)/w>-Cri&&(wcheck-w)/w<Cri)
{
fprintf(Vfile,"%.15e",V);
fprintf(Vfile,"\n");
}
F=Ff(r,A,e,p,m,Dp);

DH11=DH1(r,m,A,p,e,H1,H0,K,V);
DK1=DK(r,H0,H1,Dv,K,e,p,A,W);
DW1=DW(r,W,A,gamma,p,B,X,V,H0,K);
DX1=DX(r,X,e,p,B,Dv,H0,w,H1,K,V,A,F,W);
H1=H1+DH11*dr;
K=K+DK1*dr;
W=W+DW1*dr;
X=X+DX1*dr;
r=r+dr;
}
fclose(Wfile);
fclose(Vfile);
fclose(Bcor);
fclose(rhofile);
fclose(pfile);
fclose(mfile);
X1=X; Xp1=DX1; K1=K; H01=H0f(r,B,X,m,p,A,H1,K,w); W1=W; V1=V;

scr++;printf("\b%c",dysm[scr%6]);
/*-- 2nd solution --*/
Wfile=fopen(".\\fmode_temp\\W2.dat","w");
Vfile=fopen(".\\fmode_temp\\V2.dat","w");
mfile=fopen(".\\fmode_temp\\minside.dat","r");
rhofile=fopen(".\\fmode_temp\\einside.dat","r");
pfile=fopen(".\\fmode_temp\\pinside.dat","r");
fscanf(pfile,"%lf",&p);
fscanf(rhofile,"%lf",&e);
Bcor=fopen(".\\fmode_temp\\Bcor.dat","r");
fscanf(Bcor,"%lf",&B);
fclose(Bcor);
fclose(rhofile);
fclose(pfile);

W=1.0; K=-(e+p);
X=(e+p)*sqrt(B)*((4*pi/3*(e+3*p)-w*w/B/l)*W+0.5*K); 
H1=(2*l*K+16*pi*(e+p)*W)/l/(l+1);
rhofile=fopen(".\\fmode_temp\\einside.dat","r");
pfile=fopen(".\\fmode_temp\\pinside.dat","r");
Bcor=fopen(".\\fmode_temp\\Bcor.dat","r");
r=r0; 
while(r<=R)
{
fscanf(pfile,"%lf",&p);
fscanf(rhofile,"%lf",&e);
fscanf(Bcor,"%lf",&B);
fscanf(mfile,"%lf",&m);
if((wcheck-w)/w>-Cri&&(wcheck-w)/w<Cri)
{
fprintf(Wfile,"%.15e\n",sqrt(1-2*m/r)*W);
}

Dp=-(e+p)*(m+4*pi*r*r*r*p)/r/r/(1-2*m/r);
Dv=-2*Dp/(e+p);

A=1/(1-2*m/r);
gamma=gf(e);
H0=H0f(r,B,X,m,p,A,H1,K,w);
V=Vf(r,w,e,p,B,A,Dp,W,H0,X);
if(r==r0)V02=V;
if((wcheck-w)/w>-Cri&&(wcheck-w)/w<Cri)
{
fprintf(Vfile,"%.15e\n",V);
}
if(r==r0)V02=V;
F=Ff(r,A,e,p,m,Dp);

DH11=DH1(r,m,A,p,e,H1,H0,K,V);
DK1=DK(r,H0,H1,Dv,K,e,p,A,W);
DW1=DW(r,W,A,gamma,p,B,X,V,H0,K);
DX1=DX(r,X,e,p,B,Dv,H0,w,H1,K,V,A,F,W);
H1=H1+DH11*dr;
K=K+DK1*dr;
W=W+DW1*dr;
X=X+DX1*dr;
r=r+dr;
}
fclose(Wfile);
fclose(Vfile);
fclose(Bcor);
fclose(rhofile);
fclose(pfile);
fclose(mfile);
X2=X; Xp2=DX1;K2=K; H02=H0f(r,B,X,m,p,A,H1,K,w); W2=W; V2=V;

/*-- determing the unique solution --*/
x=-(X1-(RR-R)/(N+1)*Xp1)/(X2-(RR-R)/(N+1)*Xp2);
H0=H01+x*H02; K=K1+x*K2; W=W1+x*W2; V=V1+x*V2;V0=V01+x*V02;

/*-- Solution Review, May be skipped  --*/
if((wcheck-w)/w>-Cri&&(wcheck-w)/w<Cri)
{
Wfile1=fopen(".\\fmode_temp\\W1.dat","r");
Wfile2=fopen(".\\fmode_temp\\W2.dat","r");
Wfile=fopen(".\\fmode_temp\\W.dat","w");
Vfile1=fopen(".\\fmode_temp\\V1.dat","r");
Vfile2=fopen(".\\fmode_temp\\V2.dat","r");
Vfile=fopen(".\\fmode_temp\\V.dat","w");
r=r0;
while(r<=R)
{
fscanf(Wfile1,"%lf",&W1);
fscanf(Wfile2,"%lf",&W2);
W=W1+x*W2;
fprintf(Wfile,"%e\n",W/(1+x));
fscanf(Vfile1,"%lf",&V1);
fscanf(Vfile2,"%lf",&V2);
V=V1+x*V2;
fprintf(Vfile,"%e\n",V/V0);
r=r+dr;
}
fclose(Wfile1);
fclose(Wfile2);
fclose(Wfile);
fclose(Vfile1);
fclose(Vfile2);
fclose(Vfile);
}
if((wcheck-w)/w>-Cri&&(wcheck-w)/w<Cri)break;
wcheck=w;
/*-- BC at the surface --*/
n=0.5*(l-1)*(l+2);
aR=-(n*R+3*mR)/(w*w*R*R-(n+1)*mR/R);
bR=(n*R*(R-2*mR)-w*w*R*R*R*R+mR*(R-3*mR));
bR=bR/(R-2*mR)/(w*w*R*R-(n+1)*mR/R);
gR=n*(n+1)*R*R+3*n*mR*R+6*mR*mR;
gR=gR/R/R/(n*R+3*mR);
hR=-n*R*R+3*n*mR*R+3*mR*mR;
hR=hR/(R-2*mR)/(n*R+3*mR);
kR=-R*R/(R-2*mR);
Y1=K;
Y2=aR*H0+bR*K;
Z=(kR*Y1-Y2)/(kR*gR-hR);
DZ=(gR*Y2-hR*Y1)/(gR*kR-hR);

  /*-- check=gR*Y2-hR*Y1; --*/

/*-- Integrating the wave equation outward --*/

for(r=R;r<25.0/w;r=r+dr)
{
drx=dr/(1-2*mR/r);
VZ=(1-2*mR/r)/r/r/r/(n*r+3*mR)/(n*r+3*mR);
VZ=VZ*(2*n*n*(n+1)*r*r*r+6*n*n*mR*r*r+18*n*mR*mR*r+18*mR*mR*mR);
DDZ=(VZ-w*w)*Z;
Z=Z+DZ*drx;
DZ=DZ+DDZ*drx;
}
r=r-dr;
rx=r+2*mR*log(r/2/mR-1);

/*-- Matching the solution at infinity --*/

Ar1=2*cos(w*rx)-2*(n+1)/w/r*sin(w*rx)+1/w/w/r/r*(1.5*mR*w*(1+2/n)*sin(w*rx)-n*(n+1)*cos(w*rx));
Ai1=2*sin(w*rx)+2*(n+1)/w/r*cos(w*rx)-1/w/w/r/r*(1.5*mR*w*(1+2/n)*cos(w*rx)+n*(n+1)*sin(w*rx));
Ar2=-2*w*sin(w*rx)-2*(n+1)*cos(w*rx)/r+1/w/r/r*(1.5*mR*w*(1+2/n)*cos(w*rx)+n*(n+1)*sin(w*rx))+(1-2*mR/r)*2*(n+1)/w/r/r*sin(w*rx);
 Ai2=2*w*cos(w*rx)-2*(n+1)*sin(w*rx)/r+1/w/r/r*(1.5*mR*w*(1+2/n)*sin(w*rx)-n*(n+1)*cos(w*rx))-(1-2*mR/r)*2*(n+1)/w/r/r*cos(w*rx);

ar=(Ai2*Z-Ai1*DZ)/(Ar1*Ai2-Ar2*Ai1);
ai=-(Ar1*DZ-Ar2*Z)/(Ar1*Ai2-Ar2*Ai1); /*-- a minus sign in front because we need the complex conjugate --*/
if(t==0)
{
Ar[t]=ar;
Ai[t]=ai;
}
else
{
Ar[q]=ar;
Ai[q]=ai;
Br[0]=(o[0]*Ar[1]-o[1]*Ar[0])/(o[0]-o[1]);
Br[1]=(Ar[0]-Ar[1])/(o[0]-o[1]);
Bi[0]=(o[0]*Ai[1]-o[1]*Ai[0])/(o[0]-o[1]);
Bi[1]=(Ai[0]-Ai[1])/(o[0]-o[1]);
w=-(Br[0]*Br[1]+Bi[0]*Bi[1])/(Br[1]*Br[1]+Bi[1]*Bi[1]);
if (w<=o[0]){o[1]=o[0];o[0]=w;Ar[1]=Ar[0];Ai[1]=Ai[0];q=0;}
else if(w>=o[1]){o[0]=o[1];o[1]=w;Ar[0]=Ar[1];Ai[0]=Ai[1];q=1;}
else if((o[1]-w)>(w-o[0])){o[1]=w;q=1;}
else {o[0]=w;q=0;}
}
}
wi=(Br[0]*Bi[1]-Bi[0]*Br[1])/(Br[1]*Br[1]+Bi[1]*Bi[1]);
temp_rhoc=ne;
temp_M=mR;
temp_M=temp_M/(M*Gc2);
temp_R=RR/1000;
temp_freq=w*c/(2000*pi);
temp_dpt=1/(wi*c);
scr++;printf("\b%c",dysm[scr%6]);
}

int main()
{
	FILE *temp;
	int pf,markpf,n,len1,len2,mode;
	double srhoc[300],smass[300],sradius[300],sfreq[300],sdptime[300],rho_core;
	char outName[50],tName[30],pathName[50];
	struct EoS
	{
		char Name[30];
	};
	struct EoS list[30],denlist[30];
	system("title Advanced codes F-mode_v20     for Windows");
	temp=fopen("temp_dir.dat","w");
	fclose(temp);
	remove("temp_dir.dat");
	system("dir EoS_lib /B /ON /A-R >> temp_dir.dat");
	if((temp=fopen("temp_dir.dat","r"))==NULL){printf("No Equation of State files detected, press any key to leave.");fclose(temp);system("pause");return 0;
	}else{printf("Equation of State files detected:\n\n");}
	n=0;
while(fscanf(temp,"%s",list[n].Name)>0){printf("%d\t%s\n",n+1,list[n].Name);n++;}
len1=n;
	fclose(temp);
	remove("temp_dir.dat");
	printf("\nPlease enter the serial number of an EoS (for example 1): ");
	scanf("%d",&n);
	while((n!=(int) n)||(n<1)||(n>len1)){fflush(stdin);printf("\nPlease enter the serial number of an EoS (INTEGER-ONLY!): ");scanf("%d",&n);}
	sprintf(pathName,".\\EoS_lib\\%s",list[n-1].Name);
	if((inf=fopen(pathName,"r"))==NULL)
	{printf("Cannot load %s!\n",list[n].Name);system("pause");return 0;}
while(fscanf(inf,"%lf",&a[j])==1){fscanf(inf,"%lf",&b[j]);j++;}
fclose(inf);
rho_core=pow(10,a[j-1]);
len2=strlen(list[n-1].Name);
for(pf=0;pf<=len2-2;pf++)
{
	if(list[n-1].Name[pf]=='.'){break;}
	tName[pf]=list[n-1].Name[pf];
}
system("md fmode_temp");
printf("\n%s EoS selected!\nPlease choose a mode to decide central densities:\n\t[0]\tManual C  (enter a STARTpoint and ENDpoint)\n\t[1]\tManual T  (load a file with densities information)\n\t[2]\tAutomatic (decide the central densities for me)\n",tName);
printf("Enter a serial number: ");
fflush(stdin);scanf("%d",&mode);

if(mode==0){
double sden,eden,dstep,rhoc;
	printf("Enter STARTpoint of central density: ");
	fflush(stdin);scanf("%lf",&sden);
	printf("Enter ENDpoint of central density: ");
	fflush(stdin);scanf("%lf",&eden);
	if((eden<1e12)||(eden>5e18)||(sden<1e12)||(sden>5e18))
	{
	printf("[Manual Mode]: Warning: wrong inputs.\n");
	return 0;
	}
	printf("\nNow Loading...%c",dysm[scr%6]);
	dstep=(eden-sden)*0.03125;
	sprintf(outName,"fmode_%s_%e_%e.dat",tName,sden,eden);
	outf=fopen(outName,"w");
	fprintf(outf,"\t%-15s\t%-10s\t%-10s\t%-10s\t%-15s\n","rhoc/kg.m-3","M/Msun","R/km","frequency/kHz","damping time/s");
	pf=-1;
	for(rhoc=sden;pf<32;rhoc=rhoc+dstep)
	{
		pf++;
		fmode(rhoc);
		fprintf(outf,"\t%-15e\t%-10f\t%-10f\t%-10f\t%-15f\n",rhoc,temp_M,temp_R,temp_freq,temp_dpt);
	}
	fclose(outf);
}else if(mode==1){
	FILE *denf;
	int lenN,len0;
	char pathDen[50],tdenName[30];
	printf("\n[Manual Mode]: Place the central densities files in Central_Density document\n[Manual Mode]: Press any key to continue Manual Mode...\n");
	system("pause");
	temp=fopen("temp_cen.dat","w");
	fclose(temp);
	remove("temp_cen.dat");
	system("dir Central_Density /B /ON /A-R >> temp_cen.dat");
	if((temp=fopen("temp_cen.dat","r"))==NULL){printf("\n[Manual Mode]: No Central Density files detected, press any key to leave.");fclose(temp);system("pause");return 0;
	}else{printf("\n[Manual Mode]: Central Density files detected:\n\n");	
	}
	n=0;
	while(fscanf(temp,"%s",denlist[n].Name)>0){printf("%d\t%s\n",n+1,denlist[n].Name);n++;}
	len0=n;
	fclose(temp);
	remove("temp_cen.dat");
	printf("\n[Manual Mode]: Please select a serial number of density file (for example 1): ");
	scanf("%d",&n);
	while((n!=(int) n)||(n<1)||(n>len0)){fflush(stdin);printf("\n[Manual Mode]: Please select a serial number of density file (INTEGER-ONLY!): ");scanf("%d",&n);}
	sprintf(pathDen,".\\Central_Density\\%s",denlist[n-1].Name);
	if((denf=fopen(pathDen,"r"))==NULL)
	{printf("[Manual Mode]: Cannot load %s!\n",denlist[n].Name);system("pause");return 0;}
    printf("\nNow Loading...%c",dysm[scr%6]);
	lenN=strlen(list[n-1].Name);
    for(pf=0;pf<=lenN-2;pf++)
	{
		if(denlist[n-1].Name[pf]=='.'){break;}	
		tdenName[pf]=denlist[n-1].Name[pf];
	}
	pf=0;
	while(fscanf(denf,"%lf",&srhoc[pf])==1)
	{
		fmode(srhoc[pf]);
		smass[pf]=temp_M;sradius[pf]=temp_R;sfreq[pf]=temp_freq;sdptime[pf]=temp_dpt;
		pf++;
	}
	sprintf(outName,"fmode_%s_%s.dat",tName,tdenName);
	outf=fopen(outName,"w");
	fprintf(outf,"rhoc/kgm-3      M/Msun      R/km         frequency/kHz    damping time/s\n\n");
	printf("\b \n[Manual Mode]: Totally %d points involved, now tidying up...\n",pf);
	for(n=0;n<pf;n++)
	{
		fprintf(outf,"%e   %f    %f    %f         %f\n\n",srhoc[n],smass[n],sradius[n],sfreq[n],sdptime[n]);
	}
	fclose(outf);	
}else{

printf("\nNow Loading...%c",dysm[scr%6]);
pf=0;
srhoc[pf]=8.5e17;
fmode(srhoc[pf]);
smass[pf]=temp_M;sradius[pf]=temp_R;sfreq[pf]=temp_freq;sdptime[pf]=temp_dpt;
pf++;
srhoc[pf]=8.756e17;
fmode(srhoc[pf]);
smass[pf]=temp_M;sradius[pf]=temp_R;sfreq[pf]=temp_freq;sdptime[pf]=temp_dpt;
if((sradius[0]<20)&&(sradius[0]>6.7)&&(smass[0]>0.5)&&(smass[0]<3))
{
}else{
printf("\n\n     Unexpected errors occur when generating startpoint\n\nR0=%f\tM0=%f\tf0=%f\tdtime0=%f\n",sradius[0],smass[0],sfreq[0],sdptime[0]);
system("pause");
return 0;
}
while(pf<200)
{
if(srhoc[pf]>=rho_core)
{
break;
}
if((smass[pf]-smass[pf-1]<0.025)&&(smass[pf]-smass[pf-1]>0)&&(sradius[pf-1]-sradius[pf]<0.05))
{
	pf++;
	srhoc[pf]=3*srhoc[pf-1]-2*srhoc[pf-2];
	fmode(srhoc[pf]);
	smass[pf]=temp_M;sradius[pf]=temp_R;sfreq[pf]=temp_freq;sdptime[pf]=temp_dpt;
}else if(smass[pf]-smass[pf-1]<0.072){
	pf++;
	srhoc[pf]=2*srhoc[pf-1]-srhoc[pf-2];
	fmode(srhoc[pf]);
	smass[pf]=temp_M;sradius[pf]=temp_R;sfreq[pf]=temp_freq;sdptime[pf]=temp_dpt;
}else{
	pf++;
	srhoc[pf]=srhoc[pf-1];
	smass[pf]=smass[pf-1];sradius[pf]=sradius[pf-1];sfreq[pf]=sfreq[pf-1];sdptime[pf]=sdptime[pf-1];
	srhoc[pf-1]=0.618*srhoc[pf-2]+0.382*srhoc[pf];
	fmode(srhoc[pf-1]);
	smass[pf-1]=temp_M;sradius[pf-1]=temp_R;sfreq[pf-1]=temp_freq;sdptime[pf-1]=temp_dpt;
}
if(smass[pf]<=smass[pf-1])
{
	pf++;
	srhoc[pf]=srhoc[pf-1];
	smass[pf]=smass[pf-1];sradius[pf]=sradius[pf-1];sfreq[pf]=sfreq[pf-1];sdptime[pf]=sdptime[pf-1];
	srhoc[pf-1]=0.618*srhoc[pf-2]+0.382*srhoc[pf];
	fmode(srhoc[pf-1]);
	smass[pf-1]=temp_M;sradius[pf-1]=temp_R;sfreq[pf-1]=temp_freq;sdptime[pf-1]=temp_dpt;
	break;
}
}
markpf=pf;
pf++;
srhoc[pf]=srhoc[1];
smass[pf]=smass[1];sradius[pf]=sradius[1];sfreq[pf]=sfreq[1];sdptime[pf]=sdptime[1];
pf++;
srhoc[pf]=srhoc[0];
smass[pf]=smass[0];sradius[pf]=sradius[0];sfreq[pf]=sfreq[0];sdptime[pf]=sdptime[0];
while(pf<300)
{
	if((sradius[pf-1]-sradius[pf]<0.081)&&(sradius[pf]-sradius[pf-1]<0.081)&&(smass[pf-1]-smass[pf]<0.016))
	{pf++;
    srhoc[pf]=3*srhoc[pf-1]-2*srhoc[pf-2];
	fmode(srhoc[pf]);
	smass[pf]=temp_M;sradius[pf]=temp_R;sfreq[pf]=temp_freq;sdptime[pf]=temp_dpt;
	}else if((sradius[pf-1]-sradius[pf]<0.22)&&(sradius[pf]-sradius[pf-1]<0.22)&&(smass[pf-1]-smass[pf]<0.03))
	{pf++;
    srhoc[pf]=2*srhoc[pf-1]-1*srhoc[pf-2];
	fmode(srhoc[pf]);
	smass[pf]=temp_M;sradius[pf]=temp_R;sfreq[pf]=temp_freq;sdptime[pf]=temp_dpt;
	}else{
	pf++;
	srhoc[pf]=srhoc[pf-1];
	smass[pf]=smass[pf-1];sradius[pf]=sradius[pf-1];sfreq[pf]=sfreq[pf-1];sdptime[pf]=sdptime[pf-1];
	srhoc[pf-1]=0.5*srhoc[pf-2]+0.5*srhoc[pf];
	fmode(srhoc[pf-1]);
	smass[pf-1]=temp_M;sradius[pf-1]=temp_R;sfreq[pf-1]=temp_freq;sdptime[pf-1]=temp_dpt;
	}
	if((sradius[pf]>20||smass[pf]<0.5)) break;
}
sprintf(outName,"fmode_%s.dat",tName);
outf=fopen(outName,"w");
fprintf(outf,"rhoc/kgm-3      M/Msun      R/km         frequency/kHz    damping time/s\n\n");
printf("\b \nTotally %d points involved, now tidying up...\n",pf);
for(n=pf;n>markpf;n--)
{
	fprintf(outf,"%e   %f    %f    %f         %f\n\n",srhoc[n],smass[n],sradius[n],sfreq[n],sdptime[n]);
}
for(n=0;n<markpf+1;n++)
{
	if(srhoc[n]>srhoc[markpf+1])
	{
		fprintf(outf,"%e   %f    %f    %f         %f\n\n",srhoc[n],smass[n],sradius[n],sfreq[n],sdptime[n]);
	}
}
fclose(outf);
}
system("rd /s /q fmode_temp"); 
    printf("\nResults have been saved in [%s].\nPress any key to leave.\n",outName);
	system("pause");
	return 0;
}